# Knowledge Forge — Complete Project Guide (A → Z)

> **Current, code-verified master document** for this repository.  
> Source of truth: `src/` and `src/Migration/`. If this file and the code disagree, trust the code.  
> Created for operators and developers who need structure, flows, database meaning, and steady-state behavior in one place.  
> **Secrets never belong here** — only in `.env` (git-ignored).

Related specialized docs (still useful for deep dives):

| Doc | Focus |
|-----|--------|
| [`DATABASE_SCHEMA_AND_API_EFFECTS.md`](DATABASE_SCHEMA_AND_API_EFFECTS.md) | Column-level schema + route/command → DB write → external API |
| [`deploy/worker.md`](deploy/worker.md) | Cron / flock worker install |
| [`ORDER58_INTEGRATION.md`](ORDER58_INTEGRATION.md) | Order58 API contract notes |
| [`OPENAI_TECHNICAL_AND_COST_AUDIT.md`](OPENAI_TECHNICAL_AND_COST_AUDIT.md) | Provider cost / call patterns |

---

## Table of contents

1. [What Knowledge Forge is](#1-what-knowledge-forge-is)
2. [The architectural rule](#2-the-architectural-rule)
3. [Technology stack](#3-technology-stack)
4. [Repository & module structure](#4-repository--module-structure)
5. [How the app boots](#5-how-the-app-boots)
6. [Big-picture system flow](#6-big-picture-system-flow)
7. [Authentication: Admin vs Agent](#7-authentication-admin-vs-agent)
8. [Knowledge bases & vector stores](#8-knowledge-bases--vector-stores)
9. [Documents: upload → Ready](#9-documents-upload--ready)
10. [Background worker (cron)](#10-background-worker-cron)
11. [Order58 integration](#11-order58-integration)
12. [Rules: sync → catalog → projection → Ready](#12-rules-sync--catalog--projection--ready)
13. [Chat surfaces (Store Chat & Rule Chat)](#13-chat-surfaces-store-chat--rule-chat)
14. [Message editing](#14-message-editing)
15. [Pagination](#15-pagination)
16. [Database: all tables](#16-database-all-tables)
17. [Entity relationships](#17-entity-relationships)
18. [Routes & screens](#18-routes--screens)
19. [Console commands](#19-console-commands)
20. [Configuration (`.env`)](#20-configuration-env)
21. [Setup & deploy](#21-setup--deploy)
22. [Security model](#22-security-model)
23. [Troubleshooting](#23-troubleshooting)
24. [Operator cheat sheet](#24-operator-cheat-sheet)

---

## 1. What Knowledge Forge is

**Knowledge Forge** is a single-tenant, server-rendered knowledge-base chat application.

It solves a simple problem: **answers must come from indexed documents with real citations**, or an explicit fallback — never a free-form guess.

| Capability | Status |
|------------|--------|
| Admin login, session, throttle | Implemented |
| Knowledge base CRUD + local prompt rules | Implemented |
| Document upload / manual text / process / retry / reindex | Implemented |
| Background worker (sync → provision → process → cleanup) | Implemented |
| Grounded Store Chat (Admin + Agent) | Implemented |
| Order58 stores / knowledge / agents / rules sync | Implemented |
| Rules catalog, classification, global projection | Implemented |
| Dedicated Rule Chat (Admin + Agent) | Implemented |
| Rule Readiness UI | Implemented |
| Shared list pagination | Implemented |
| Multi-tenant SaaS / streaming / S3 / DOCX | **Not** implemented |

---

## 2. The architectural rule

> **A web request never calls OpenAI for indexing.**  
> Upload, Process next, Re-index, Retry, Sync Rules, Review — only write local DB rows and return.  
> The cron worker owns all OpenAI (and Order58 sync drain) network work.

**Exception on the web tier:** chat ask/edit regenerate (`POST /responses` via File Search) is synchronous. Agent login also calls Order58 authenticate synchronously.

**There is no Redis/SQS.** Status columns **are** the queues:

| Queue (rows) | Worker stage |
|--------------|--------------|
| `integration_sync_runs` `status='pending'`/`running` | 1. Order58 sync |
| `knowledge_bases` `vector_store_status='pending'` | 2. Provision vector store |
| `documents` `status IN ('queued','indexing')` | 3. Process / poll index |
| `document_index_files` `pending_removal=1` | 4. Remote cleanup |

---

## 3. Technology stack

| Layer | Choice |
|-------|--------|
| Language | PHP 8.2–8.5 |
| Framework | Yii3 (`yiisoft/*`) — DI, router, DB, views, session, CSRF, migrations |
| Database | MySQL 8.0+ (InnoDB, `utf8mb4`, UTC timestamps) |
| Web | nginx + PHP-FPM; doc root = `public/` only |
| OpenAI | Custom typed HTTP gateway (Guzzle) — **no official SDK** |
| Retrieval | Hosted Vector Stores + File Search |
| PDF probe | `smalot/pdfparser` |
| Markdown | `league/commonmark` |
| Config | `.env` → `src/Environment.php` only |

---

## 4. Repository & module structure

```
knowledge-forge/
├── public/                 # HTTP doc root
├── config/                 # DI, routes, params (common / web / console)
├── runtime/                # storage, locks, logs (outside web root)
├── docs/                   # this guide + specialized docs
├── tests/                  # Unit / Integration / Console / Functional / Web
└── src/                    # Application code (PSR-4 App\)
    ├── Shared/             # Clock, transactions, markdown, middleware, pager
    ├── Auth/               # Admin login
    ├── Agent/              # Order58 agent realm + UI
    ├── KnowledgeBase/      # KB CRUD, prompt rules, provisioning
    ├── Document/           # Upload, processors, cleanup
    ├── Chat/               # Ask, grounding, citations, edit, Rule Chat web
    ├── Order58/            # Sync client, mirrors, IntegrationSyncDrainer
    ├── Rules/              # Catalog, classification, projection, readiness
    ├── Ai/                 # OpenAI ports, operation ledger, usage
    ├── Worker/             # flock lock + WorkerRunner
    ├── Web/                # Dashboard + shared layout/pager
    ├── Console/            # Health / hello
    └── Migration/          # Schema history
```

**Typical layering inside a domain:**

```
Web (Action + template)
  → Application (service)
    → Domain (entities / enums / ports)
      ← Infrastructure (MySQL / disk / HTTP)
```

---

## 5. How the app boots

1. `public/index.php` (web) or `yii` (console) loads Composer autoload.
2. `src/bootstrap.php` loads `.env` and initializes `Environment`.
3. Yii DI builds the container from `config/`.
4. Web: router + middleware (session, CSRF, auth). Console: Symfony commands registered in `config/console/commands.php`.

Missing/malformed required env vars fail fast with a secret-free error.

---

## 6. Big-picture system flow

```
┌──────────────────┐     ┌─────────────────────┐     ┌──────────────────────────┐
│ Admin / Agent UI │────▶│ MySQL               │────▶│ OpenAI                   │
│ (Yii3)           │     │ knowledge_bases     │     │ Vector Store (1 per KB)  │
└────────┬─────────┘     │ documents           │     │ + indexed files          │
         │               │ conversations…      │     │ File Search at chat time │
         │               │ order58_* / rules_* │     └──────────────────────────┘
         │               └──────────▲──────────┘
         │                          │
         │               ┌──────────┴──────────┐
         └──────────────▶│ Cron: kf:worker:run │  flock-locked
                         │ sync→provision→     │
                         │ process→cleanup     │
                         └─────────────────────┘
```

### Path A — Manual knowledge base

1. Admin creates KB → `vector_store_status=pending`
2. Worker provisions OpenAI vector store → `ready`
3. Admin uploads documents → `documents.status=queued`
4. Worker indexes → `ready`
5. Admin chats with forced File Search + grounding

### Path B — Order58 store

1. Sync stores → `order58_stores` + ensure store KB
2. Sync knowledge → `order58_knowledge_records` + generated docs
3. Same provision/index path as Path A
4. Agents see store when source active + agent enabled + VS ready + usable qualifying docs

### Path C — Order58 rules → Rule Chat

1. Sync rules → `order58_rule_records` (new/changed/unchanged semantics)
2. Catalog + classify → `rule_catalog_*`
3. Successful full sync auto-reconciles global projections
4. Hidden KB `order58-common-rules` ensured; `order58_rule_global` docs queued
5. Worker provisions/indexes → Rule Readiness → Ready
6. When ≥1 Ready global rule: Admin/Agent Rule Chat unlocks

---

## 7. Authentication: Admin vs Agent

| Realm | How | Session | Access |
|-------|-----|---------|--------|
| **Admin** | Local `admin_users` password | Admin session | Full admin UI |
| **Agent** | Order58 `POST /authenticate` | Separate agent session | Agent store directory + chats only |

**Agent admit rules (code):** `user_type === 'agent'` and `status === 'active'`. Password is never stored locally.

**Conversation isolation:**

- `conversations.participant_type` = `admin` | `agent`
- `conversations.participant_id` = admin user id **or** Order58 `admin_id`
- Unique thread per `(knowledge_base_id, participant_type, participant_id)`
- Admin id `N` and agent id `N` are **different owners**
- Agents never reach admin routes

Login throttle: `auth_login_attempts` (keyed by username\|IP hash).

---

## 8. Knowledge bases & vector stores

### Table: `knowledge_bases`

One row = one searchable corpus = **one OpenAI vector store**.

| Field group | Meaning |
|-------------|---------|
| `name`, `slug`, `description`, `system_instructions` | Display + chat prompt |
| `status` | `active` \| `archived` |
| `vector_store_status` | `pending` → `provisioning` → `ready` \| `failed` |
| `openai_vector_store_id` | Remote store id when ready |
| `source_system`, `source_store_id`, `source_active`, `agent_enabled` | Order58 store mapping |
| `purpose` | `store` (default) \| `shared_rules` |

### Purposes

| Purpose | Who sees it | Example |
|---------|-------------|---------|
| `store` | Admin KB list / store directory | Manual KBs + Order58 store KBs |
| `shared_rules` | Hidden (not in store directories) | Slug **`order58-common-rules`**, `source_system=order58_rules`, `agent_enabled=0` |

Hidden rules KB is created lazily by `EnsureCommonRulesKnowledgeBaseService` when the first global projection needs a home. It still uses the normal provisioning lifecycle.

### Chat-ready (Store Chat)

Roughly:

```
KB active
AND vector_store_status = ready
AND openai_vector_store_id IS NOT NULL
AND ≥1 usable qualifying document (not store profile-only, not rule projections)
(+ Order58: source_active + usable store profile as required by ChatAvailabilityPolicy)
(+ Agent: agent_enabled = 1)
```

---

## 9. Documents: upload → Ready

### Status lifecycle (`documents.status`)

```
uploaded → queued → processing → indexing → ready
                                   ↘ failed
deleted (soft)
```

- Web upload/enqueue reaches **`queued` only**.
- Worker claims and advances.
- Soft `deleted` frees dedupe and keeps audit; remote files cleaned via `pending_removal`.

### Source types (`documents.source_type`)

| Value | Origin | Qualifies Store Chat alone? | Store Chat citation? | Rule Chat citation? |
|-------|--------|-----------------------------|----------------------|---------------------|
| `uploaded_pdf` / `uploaded_image` / `uploaded_text` / `manual_text` | Admin | Yes | Yes | No |
| `order58_knowledge` | Knowledge sync | Yes | Yes | No |
| `order58_store_profile` | Store sync | **No** | Yes (metadata) | No |
| `order58_rule_global` | Rule projection | **No** | **No** | **Yes** |
| `order58_rule_common` | Legacy projection | **No** | **No** | **Yes** (legacy) |
| `order58_rule_store` | Legacy store projection | **No** | **No** | No — **no longer created**; retired by reconciler |

### Index files (`document_index_files`)

- Tracks OpenAI file attachments per document (`role`: `source` \| `derived_markdown`)
- `index_status`: `pending` → `in_progress` → `completed` \| `failed` \| `cancelled`
- Reindex/delete flags `pending_removal=1`; cleanup drainer removes remote file when safe

### Related tables

- `document_processing_events` — append-only processing audit
- `ai_operations` — durable OpenAI operation ledger (`pending|in_flight|succeeded|needs_reconcile|failed`)

---

## 10. Background worker (cron)

Command: `./yii kf:worker:run [--limit=N]`

Lock: `flock` on `DOCUMENT_WORKER_LOCK_PATH` (see `docs/deploy/worker.md`).

### Drainer order (one pass)

1. **`IntegrationSyncDrainer`** — claim/run `integration_sync_runs` (Order58)
2. **`KnowledgeBaseProvisioningDrainer`** — create vector stores for `pending` KBs
3. **`DocumentProcessingDrainer`** — process queued/indexing documents (requires KB VS ready)
4. **`RemoteCleanupDrainer`** — detach/delete OpenAI files marked `pending_removal`

### Daily Order58 schedule (America/New_York)

| Time | Command | Effect |
|------|---------|--------|
| 02:00 | `kf:order58:schedule-knowledge` | Enqueue knowledge sync for NY calendar day |
| 03:00 | `kf:order58:schedule-rules` | Enqueue rules sync for NY calendar day |
| * * * * * | `kf:worker:run --limit=1` | Drain everything above |

Admin “Sync” buttons enqueue the same `integration_sync_runs` table (not the daily schedule table).

---

## 11. Order58 integration

### Mirror tables

| Table | Meaning |
|-------|---------|
| `order58_stores` | Store accounts |
| `order58_agents` | Agent profiles (login identity; not store ACL) |
| `order58_knowledge_records` | Per-store knowledge articles |
| `order58_rule_records` | Source rules from Rules API |
| `integration_sync_runs` | Sync job queue + progress |
| `order58_daily_sync_schedules` | Idempotent daily enqueue markers |

### Sync types

`stores` · `knowledge` · `knowledge_store` · `agents` · `rules` · `rebuild_store` · `health`

### Mark-and-sweep (all mirrors)

1. While paging: stamp `last_seen_sync_run_id`
2. **Only after a successful full scan:** soft-deactivate rows not seen this run
3. Partial / failed / interrupted runs **never** deactivate unseen rows

### Rules sync semantics (current permanent behavior)

Order58 Rules API **does not** expose an explicit `active` field today. Presence in a successful list response means active. If `active` appears later, it is honored.

| Case | Behavior |
|------|----------|
| **New** | INSERT mirror → catalog link → classify → project |
| **Changed** (sync hash) | UPDATE content → catalog reconcile → classify → project |
| **Unchanged** | Skip content rewrite / reclassify / unnecessary reindex; **still** restore `is_active` from upstream truth |
| **Missing after full scan** | Soft-deactivate + recompute canonical + retire projection |
| **Missing after partial/failed** | Untouched |

After a **successful full** Rules sync, `RulesSyncHandler` automatically runs `RuleReconciliationRunner::reconcileAllActive()` (local queue only — no OpenAI in the HTTP/sync path).

Safe dry-run preview of stale lifecycle: `kf:rules:repair-lifecycle --dry-run` (never mass-reactivates offline; next successful Sync Rules self-heals).

---

## 12. Rules: sync → catalog → projection → Ready

### Pipeline

```
Order58 Rules API
    ↓ RulesSyncHandler
order58_rule_records          (source mirror)
    ↓ RuleCatalogService
rule_catalog_rules            (canonical, content-deduped)
rule_catalog_sources          (primary / exact_duplicate)
    ↓ RuleClassificationRunner
rule_store_links + events     (deterministic; never overwrite admin decisions)
    ↓ RuleProjectionReconciler (after sync / review)
documents source_type=order58_rule_global
    in knowledge_bases slug=order58-common-rules
    ↓ Worker provision + process
Ready index file → Rule Chat can open
```

### Canonical activity

A canonical rule is `is_active=1` when **at least one** linked source record is active. Recomputed after save / markSeen reactivation / sweep.

Retrieval availability for Rule Chat is gated by:

- canonical `is_active`
- `is_globally_available` (default on; off when ignored/disabled)
- usable Ready `order58_rule_global` document

Classification (`pending`, `auto_matched`, `confirmed_common`, …) does **not** by itself gate global projection.

### Rule Readiness UI (`/admin/order58/rules/readiness`)

Outer grain = synced `order58_rule_records`. Derived statuses:

| Status | Meaning |
|--------|---------|
| `inactive` | Source `is_active=0` |
| `disabled` | Projection disabled / not globally available |
| `not_materialized` | Active but no global document yet |
| `queued` / `processing` / `indexing` | Document pipeline in flight |
| `failed` | Index/document failed |
| `ready` | Live global projection, enabled, completed index, `openai_file_id` present, `pending_removal=0` |

**Ready is never faked.** Rule Chat unlocks only when Ready global rules ≥ 1.

### Important: store-rule projections removed

Store Chat must answer only from genuine store knowledge. The system **no longer creates** `order58_rule_store` documents. Legacy ones are retired by reconcile / `kf:rules:retire-store-projections`.

---

## 13. Chat surfaces (Store Chat & Rule Chat)

| Surface | Routes | Corpus | Retrieval scope |
|---------|--------|--------|-----------------|
| Admin Store / KB Chat | `/knowledge-bases/{slug}/chat…` | That KB’s vector store | `store_knowledge` |
| Admin Store Chat picker | `/admin/order58/store-chat` | Opens a store KB | `store_knowledge` |
| Agent Store Chat | `/agent/stores/{slug}/chat…` | Agent-eligible store KB | `store_knowledge` |
| Admin Rule Chat | `/admin/rule-chat…` | Hidden `order58-common-rules` | `rule_only` |
| Agent Rule Chat | `/agent/rule-chat…` | Same hidden KB | `rule_only` |

### Retrieval / citation scopes (`ChatRetrievalScope`)

| Scope | Allowed document sources |
|-------|--------------------------|
| `store_knowledge` | Anything **except** Order58 rule projections |
| `rule_only` | Only `order58_rule_global` (+ legacy `order58_rule_common`) |

Grounding: no usable retrieval / no resolvable in-scope citation ⇒ configured fallback message (never a guess).

### Availability gates

- **Store Chat:** `ChatAvailabilityPolicy` (qualifying docs, VS ready, Order58 source rules as applicable)
- **Rule Chat:** `RuleChatAvailability` / `CommonRulesReadiness` — hidden KB ready **and** ≥1 usable Ready global-rule document

Synced / Active / Queued / Indexing alone does **not** enable Rule Chat.

---

## 14. Message editing

Shared service: `EditChatMessageService` (Admin + Agent, Store + Rule Chat).

| Rule | Behavior |
|------|----------|
| Who | Only the thread owner (typed participant) |
| What | Only the **latest** user question |
| Age | **No time limit** (minutes/days/months OK) |
| Older questions | Always rejected (`NotLatestQuestion`) |
| Empty / unchanged | Rejected |
| Audit | `message_revisions` + `edit_count` optimistic lock |
| Answer | Previous assistant answer superseded; exactly one new active answer regenerated |
| Scope preserved | Store edit → `StoreKnowledge`; Rule edit → `RuleOnly` |

UI pencil icon comes from server-side `MessageEditView` (latest-question only). No “editable for 20 minutes” config remains.

Retry regenerate is allowed when the latest question has no active answer (recoverable failure state).

---

## 15. Pagination

Shared helper: `src/Web/Shared/Pagination/PageWindow.php`  
Partial: `src/Web/Shared/_partial/pager.php`

Used on list screens such as Order58 Stores, Store Chat picker, Agent home, Rule list, Rule readiness, Global rules base.

Chat “Load older” and Order58 API paging are separate mechanisms.

---

## 16. Database: all tables

Migrations live in `src/Migration/`. Below is the **purpose map** (not every column).

### Auth

| Table | Purpose |
|-------|---------|
| `admin_users` | Local administrators |
| `auth_login_attempts` | Login throttle windows |

### Knowledge bases

| Table | Purpose |
|-------|---------|
| `knowledge_bases` | One corpus + one vector store |
| `knowledge_base_rules` | Admin-authored **prompt** rules (not Order58 rules) |

### Documents & AI ledger

| Table | Purpose |
|-------|---------|
| `documents` | Uploaded or generated content units |
| `document_index_files` | OpenAI file attachments + removal flags |
| `document_processing_events` | Processing audit trail |
| `ai_operations` | Idempotent OpenAI operation ledger |

### Chat

| Table | Purpose |
|-------|---------|
| `conversations` | One thread per (KB, participant type, participant id) |
| `messages` | User/assistant turns; supersede + edit metadata |
| `message_revisions` | Prior question text history |

### Order58 mirrors & sync

| Table | Purpose |
|-------|---------|
| `order58_stores` | Store mirror |
| `order58_agents` | Agent profile mirror |
| `order58_knowledge_records` | Knowledge article mirror |
| `order58_rule_records` | Rule source mirror |
| `integration_sync_runs` | Sync job queue |
| `order58_daily_sync_schedules` | Daily schedule idempotency |

### Rules catalog

| Table | Purpose |
|-------|---------|
| `rule_catalog_rules` | Canonical deduped rules |
| `rule_catalog_sources` | Source → canonical links |
| `order58_store_aliases` | Store name/alias seeds for matching |
| `rule_store_links` | Suggested/confirmed/rejected store matches |
| `rule_classification_events` | Classification audit |

---

## 17. Entity relationships

```
admin_users ──< conversations >── knowledge_bases
agent (Order58 admin_id) ──< conversations

knowledge_bases ──< documents ──< document_index_files
knowledge_bases ──< knowledge_base_rules
knowledge_bases ──< conversations ──< messages ──< message_revisions

order58_stores ──(ensure)──> knowledge_bases (source_system=order58)
order58_knowledge_records ──(generate)──> documents (order58_knowledge)

order58_rule_records ──< rule_catalog_sources >── rule_catalog_rules
rule_catalog_rules ──(project)──> documents (order58_rule_global)
                                  in knowledge_bases (slug=order58-common-rules)

integration_sync_runs drives Order58 handlers
order58_daily_sync_schedules enqueues those runs once per NY day
```

---

## 18. Routes & screens

Full map: `config/common/routes.php`.

### Public

- `/login` — admin
- `/agent/login` — agent

### Admin (RequireAdmin)

- `/` — dashboard
- `/knowledge-bases…` — KB CRUD, documents, manual text, Store/KB chat
- `/admin/order58…` — sync, stores, agents, rules report/list/detail/review/readiness/global
- `/admin/order58/store-chat` — store chat picker
- `/admin/rule-chat…` — Rule Chat
- `/admin/openai-usage` — usage diagnostic

### Agent (RequireAgent)

- `/agent` — store directory
- `/agent/stores/{slug}/chat…` — Store Chat
- `/agent/rule-chat…` — Rule Chat

---

## 19. Console commands

Registered in `config/console/commands.php`:

| Command | Role |
|---------|------|
| `kf:health` | Config + DB fingerprint (no OpenAI) |
| `kf:openai:ping` | Live OpenAI capability check |
| `kf:admin:create` | Create first/admin user |
| `kf:worker:run [--limit=N]` | One worker pass |
| `kf:documents:recover` | Unstick processing documents |
| `kf:ai:reconcile` | Resolve ambiguous AI operations |
| `kf:order58:reconcile-active` | Repair store `source_active` from snapshot |
| `kf:order58:schedule-knowledge` | Daily knowledge enqueue |
| `kf:order58:schedule-rules` | Daily rules enqueue |
| `kf:rules:reconcile-global` | Backfill/reconcile global rule projections |
| `kf:rules:repair-lifecycle --dry-run` | Preview stale inactive/unmaterialized rules |
| `kf:rules:retire-store-projections` | Retire legacy store-rule documents |

Also: `chat:thread-merge-report`, `chat:participant-backfill-report`, `hello`.

---

## 20. Configuration (`.env`)

All keys are declared in `src/Environment.php` and documented in `.env.example`.

| Category | Examples |
|----------|----------|
| App | `APP_ENV`, `APP_DEBUG`, `APP_TIMEZONE`, `APP_BASE_PATH` |
| Auth throttle | `AUTH_MAX_LOGIN_ATTEMPTS`, window/lockout minutes |
| Database | `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, … |
| OpenAI | `OPENAI_API_KEY`, chat/vision models, timeouts, retries |
| Storage / uploads | `KNOWLEDGE_STORAGE_PATH`, size caps |
| Worker | batch size, attempts, timeout, lock path |
| Chat | history limits, force file search, citations, fallback text |
| Order58 | API base URL/credentials, page size, pages per run |

**Note:** there is **no** chat edit time-window setting. Latest-question edit has no age limit.

One `.env` for PHP-FPM and cron (same user) so config cannot drift. Confirm with `kf:health` fingerprints.

---

## 21. Setup & deploy

```bash
composer install --no-dev          # or without --no-dev for local
cp .env.example .env               # edit secrets + models
./yii migrate:up
./yii kf:health
./yii kf:openai:ping               # live key check
./yii kf:admin:create
```

Then:

1. nginx vhost (`docs/nginx/`)
2. permissions (`docs/deploy/fix-permissions.sh`)
3. worker cron (`docs/deploy/worker.md`)
4. optional daily Order58 schedule cron (same deploy doc)

---

## 22. Security model

- Doc root is `public/` only; storage under `runtime/`
- CSRF on state-changing POSTs
- Admin and Agent middleware isolation
- Conversation ownership always resolved server-side (forged ids ⇒ 404)
- Secrets redacted from logs (`SecretRedactor`)
- Chat grounding refuses out-of-scope citations
- Order58 agent passwords never persisted
- `APP_DEBUG=false` in production

---

## 23. Troubleshooting

| Symptom | Check |
|---------|-------|
| Upload stuck Queued | Worker cron running? flock lock? KB `vector_store_status`? |
| KB never Ready | Provisioning failed? `kf:ai:reconcile` / logs |
| Store Chat unavailable | Qualifying docs Ready? Order58 `source_active`? Agent `agent_enabled`? |
| Rule Chat unavailable | Ready global rules ≥ 1? Hidden KB provisioned? |
| Rules stuck Inactive after sync | Fixed permanently in Rules sync `markSeen` active restore — run Sync Rules again |
| Partial sync deactivated rules? | Should not — sweep only on successful full scan |
| Edit pencil missing | Must be latest user question; chat must be available |
| Cannot edit old latest question | Age is allowed now — check ownership / latest / CSRF |
| Duplicate answers | Should be impossible (`active_answer_key`); regenerate is idempotent |

Useful commands: `kf:health`, `kf:worker:run --limit=1`, `kf:documents:recover`, `kf:rules:repair-lifecycle --dry-run`.

---

## 24. Operator cheat sheet

### Steady-state day

```
02:00 NY  schedule-knowledge
03:00 NY  schedule-rules
every min worker:run
    → sync pages
    → (rules) catalog + auto global reconcile
    → provision hidden/store KBs
    → index documents
    → cleanup pending_removal
    → Rule Readiness advances
    → Rule Chat unlocks when Ready ≥ 1
```

### Manual heal after deploy / stale rules

1. Admin → Order58 → **Sync Rules** (full successful run)
2. Let worker cron finish indexing
3. Check `/admin/order58/rules/readiness`
4. When Ready ≥ 1, open Admin/Agent Rule Chat

Optional preview only:

```bash
./yii kf:rules:repair-lifecycle --dry-run
```

### Do not

- Call OpenAI indexing from the browser
- Mass-SQL `UPDATE … is_active=1` as the primary repair
- Expect Rule Chat from Synced/Active alone
- Expect Store Chat to cite rule projections

---

## Appendix A — Worker one-pass diagram

```
kf:worker:run
 ├─ recover stuck documents (timeout)
 ├─ IntegrationSyncDrainer
 │    └─ stores | knowledge | agents | rules | rebuild | health
 ├─ KnowledgeBaseProvisioningDrainer
 │    └─ pending → provisioning → ready|failed
 ├─ DocumentProcessingDrainer
 │    └─ queued → processing → indexing → ready|failed
 └─ RemoteCleanupDrainer
      └─ pending_removal OpenAI files
```

## Appendix B — Rules sync decision tree

```
fetch page of rules
for each rule:
  hash unchanged?
    yes → markSeen(active) ; if activity changed → recompute + reconcile
           skip content rewrite / reclassify
    no  → save mirror ; link catalog ; classify (+ reconcile)
end of pages?
  no more + pagesPerRun hit → PARTIAL (no sweep, no full reconcile-all)
  no more + final page OK →
      deactivateNotSeen
      recompute + reconcile deactivated
      reconcileAllActive()   ← auto materialize globals
      COMPLETED
```

## Appendix C — Code entry points (quick)

| Concern | Start here |
|---------|------------|
| Worker order | `config/common/di/worker.php` |
| Rules sync | `src/Order58/Application/Sync/RulesSyncHandler.php` |
| Global projection | `src/Rules/Application/RuleProjectionReconciler.php` |
| Hidden rules KB | `src/Rules/Application/EnsureCommonRulesKnowledgeBaseService.php` |
| Store Chat ask | `src/Chat/Application/AskKnowledgeBaseService.php` |
| Scopes | `src/Chat/Domain/ChatRetrievalScope.php` |
| Edit | `src/Chat/Application/EditChatMessageService.php` |
| Readiness | `src/Rules/Infrastructure/DbRuleReadinessReader.php` |
| Routes | `config/common/routes.php` |
| Env schema | `src/Environment.php` |

---

*End of guide. Prefer this file for current A→Z orientation; prefer `DATABASE_SCHEMA_AND_API_EFFECTS.md` when you need every column and every write path.*
